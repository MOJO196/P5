using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Level_Loader : MonoBehaviour
{
    public GameObject crossfade;
    public static Level_Loader instance;
    public GameOverScreen gameOverScreen;
    void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
        }
        crossfade.SetActive(true);
    }
    public Animator transition;
    public float transtionTime = 1f;

    public void LoadNextLevel ()
    {
        GameStats.currenLevel++;
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex+1));        
    }

    public void ReloadLevel ()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex));
    }

    public void SetCurrentScene (int level)
    {
        GameStats.currenLevel = level;

        if(level == 0)
        {
            StartCoroutine(GameOver());
        }
        else
        {
            SceneManager.LoadScene(level);
        }
    }

    IEnumerator GameOver ()
    {
        gameOverScreen.Setup();
        Debug.Log("Start");
        yield return new WaitForSeconds(5);
        Debug.Log("Ende");
        GameStats.score = 0;
        GameStats.lifes = 3;
        SceneManager.LoadScene(0);
        yield return new WaitForSeconds(transtionTime);
    }

    IEnumerator LoadLevel (int levelIndex)
    {
        transition.SetTrigger("Start");
        yield return new WaitForSeconds(transtionTime);
        SceneManager.LoadScene(levelIndex);
    }
}
