﻿using System.Diagnostics;
public static class GameStats
{
    public static int score;
    public static int currenLevel;
    public static int lifes = 3;
    public static float health;
    public static int player = 1;
}